Otsu
=====

Otsu thresholding in C++

* WORK IN PROGRESS *


<a href="https://en.wikipedia.org/wiki/Otsu's_method">https://en.wikipedia.org/wiki/Otsu's_method</a>


<img src="results/valve_original.png" width="550">

(C)Bruno Keymolen, bruno.keymolen@gmail.com
